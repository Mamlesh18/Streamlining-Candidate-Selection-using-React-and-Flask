// FrontPage.js

import React from 'react';

import Header from './components/admin/header_1';
import Filter from './components/admin/filter_1';
function Admin() {
  return (
    <div>
      <Header />
      <Filter /> 
    </div>
  );
}
export default Admin;
